<?php
    define("COM_RESTRICAO_RESERVA_DOMINIO",              3221);
    define("COM_RESTRICAO_BLOQUEIO_ADMINISTRATIVO",      3222);
    define("SEM_RESTRICOES",                             3220);
    define("COM_RESTRICAO_RESERVA_E_BLOQUEIO",           3223);


    require('nusoap.php');
    require('xml.functions.php');

    $msg=$_POST["renavam"];
    if ($_POST["renavam"] == "") {
       echo("Campo do renavam em branco");
    }
    else{
        $wcClient  = new soapclient('http://200.175.177.169/URA/URA?WSDL','wsdl');
        $msg = '711355274';
        $Response = $wcClient->call('consultaRestricaoBloqueioVeiculo', array($msg));
        if ($wcClient->getError()) {
            echo '<br><br><br>ERROR<xmp>' . $wcClient->getError() . '</xmp>';
        }
        else {
            $xResponse = xmlize($Response);
            $dados = $xResponse["saida"]["#"];

            echo "<table><tr>";
/*            echo "<td>".$dados["resposta"]['0']['#']."</td>";
            echo "<td>".$dados["descricao-reposta"]['0']['#']."</td>";

            $dados = $dados["dados"]['0']["#"];
            echo "<td>".$dados["chassi"]['0']['#']."</td>";
            echo "<td>".$dados["placa"]['0']['#']."</td>";
            echo "<td>".$dados["renavan"]['0']['#']."</td>";
  */
            $dados = $dados["dados"]['0']["#"];
            $reserva_dominio=($dados["reserva-dominio"]['0']['#']);
            $bloquio_administrativo=($dados["bloqueio-administrativo"]['0']['#']);
            
            if($reserva_dominio>0 AND $bloquio_administrativo==0){
                echo "<td>".COM_RESTRICAO_RESERVA_DOMINIO."</td>"; 
            }else{
                if($reserva_dominio=0 AND $bloquio_administrativo>0){
                    echo "<td>".COM_RESTRICAO_BLOQUEIO_ADMINISTRATIVO."</td>";
                }else{
                    if($reserva_dominio>0 AND $bloquio_administrativo>0){
                        echo "<td>".COM_RESTRICAO_RESERVA_E_BLOQUEIO."</td>";
                    }else{
                        echo "<td>".SEM_RESTRICOES."</td>";
                    }
                }
            }
              
/*          echo "<td>".$dados["reserva-dominio"]['0']['#']."</td>";
//          echo "<td>".$dados["descricao-reserva-dominio"]['0']['#']."</td>";
            echo "<td>".$dados["bloqueio-administrativo"]['0']['#']."</td>";
//          echo "<td>".$dados["descricao-bloqueio-administrativo"]['0']['#']."</td>";
*/            echo "</tr></table>";

        }
    }

?>

