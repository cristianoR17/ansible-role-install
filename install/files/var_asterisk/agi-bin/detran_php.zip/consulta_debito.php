<?php

    require('nusoap.php');
    require('xml.functions.php');


    $msg=$_POST["renavam"];
    if ($_POST["renavam"] == "") {
       echo("Campo do renavam em branco");
    }
    else{
        $wcClient  = new soapclient('http://200.175.177.169/URA/URA?WSDL','wsdl');
        //$msg = '711355274';
        $Response = $wcClient->call('consultaDebitoVeiculo', array($msg));
        if ($wcClient->getError()) {
            echo '<br><br><br>ERROR<xmp>' . $wcClient->getError() . '</xmp>';
        }
        else {
            $xResponse = xmlize($Response);
            $dados = $xResponse["saida"]["#"];
/*
            echo "<table><tr>";
            echo "<td>".$dados["resposta"]['0']['#']."</td>";
            echo "<td>".$dados["descricao-reposta"]['0']['#']."</td>";

            $dados = $dados["dados"]['0']["#"];
            echo "<td>".$dados["chassi"]['0']['#']."</td>";
            echo "<td>".$dados["licenciamento"]['0']['#']."</td>";
            echo "<td>".$dados["multa"]['0']['#']."</td>";
            echo "<td>".$dados["seguro"]['0']['#']."</td>";
            echo "<td>".$dados["taxa"]['0']['#']."</td>";
            echo "<td>".$dados["ipva-vencer"]['0']['#']."</td>";
            echo "<td>".$dados["ipva-vencido"]['0']['#']."</td>";
            echo "</tr></table>";
*/
            $dados = $dados["dados"]['0']["#"];
            $seguro = $dados["seguro"]['0']['#']*100;
            $multa  = $dados["multa"]['0']['#']*100;
            $licenc = $dados["licenciamento"]['0']['#']*100;
            $taxa = $dados["taxa"]['0']['#'];
            $ipva_vencer = $dados["ipva-vencer"]['0']['#'];
            $ipva_vencido = $dados["ipva-vencido"]['0']['#'];

            echo "<table><tr>";
            echo "<td>".$seguro."</td>";
            echo "<td>".$multa."</td>";
            echo "<td>".$licenc."</td>";
            echo "<td>".$taxa."</td>";
            echo "<td>".$ipva_vencer."</td>";
            echo "<td>".$ipva_vencido."</td>";
            echo "<td>".($seguro+$multa+$licenc+$taxa+$ipva_vencer+$ipva_vencido)."</td>";
            echo "</tr></table>";
        }

    }


?>


